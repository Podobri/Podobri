
$(document).ready(function(){
	$('.cal-item').on('click', function() {
		$('.cal-events-list-container').slideUp(300).slideDown(300);
	})

});

	


